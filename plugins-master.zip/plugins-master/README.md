# UnethicalPlugins
My free to use Unethical plugins
For suggestions or features/bugs contact WaRp#9721

# Current Plugins:
	* WarpCrabs - Sand crab killer supports 4 spots and Alching can pick up ammo.
	* WarpCutter - Supports multiple locations/Powerchopping anywhere, Special attack, Bird nest.
	* WarpGauntlet - Hunllef helper Eat/Prayer swap/Weapon swap/Drink pots.
	* WarpSkiller - Cuts gems, Fletches Bows (u), High/Low alch, Superheat iron, Make potions, Clean herbs.
	* WarpMasterThieving - Draynor Masterfarmer robber. Support eating and banking/dropping.
	* WarpVyreKiller - Kills Vyrewatch Sentinels, Recharges prayer and banks loot.

# How to add:
	Repository owner: WaRpProjects 	
	Repository name: UnethicalPlugins

